(function() {

    'use strict';

    angular
        .module('coinex-app.use-cases.asignacion')
        .controller('asignacionController', asignacionController)

    function asignacionController($scope, $mdToast, confirmModal ) {   
       
        angular.extend($scope, {
        });

        function init() {
          
        }

       
    }

})();
