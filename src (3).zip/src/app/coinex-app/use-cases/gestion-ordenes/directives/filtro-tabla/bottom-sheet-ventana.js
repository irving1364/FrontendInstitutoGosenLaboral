(function() {

	'use strict';

	angular
		.module('coinex-app.use-cases.gestion-ordenes')
		.controller('bottomSheetVentanaController', bottomSheetVentanaController);


	function bottomSheetVentanaController() {
		
	}
	
})();