(function() {

	'use strict';

	angular.module('coinex-app.draglet', []);


})();