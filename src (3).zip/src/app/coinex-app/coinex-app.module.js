(function() {

	'use strict';

	angular.module('coinex-app', [
		'coinex-app.services',
		'coinex-app.draglet',
		'coinex-app.use-cases',
		'coinex-app.directives'
	]);


})();